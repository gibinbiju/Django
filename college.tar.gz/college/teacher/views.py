from django.shortcuts import render

def register(request):
    return render(request,'css/registration.html')

def login(request):
    return render(request,'css/login.html')
