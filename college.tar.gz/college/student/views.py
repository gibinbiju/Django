from django.shortcuts import render

def register(request):
    return render(request,'images/registration.html')

def login(request):
    return render(request,'images/login.html')
